python /home/miguel/breast_cancer_networks/parallel_aracne/genera_condor.py \
    --path_to_aracne2 /home/miguel/ARACNE/aracne2 \
    --expfile /home/miguel/PROJECT/exp_0.txt \
    --probes /home/miguel/PROJECT/probesets.txt \
    --run_id SG_0_aracne \
    --outdir /home/miguel/PROJECT/SG_0_aracne \
    --p 1

# Poner en el encabezado de .condor
# requirements = Machine == "notron.inmegen.gob.mx"

# Dentro del outdir darle:
# condor_submit 