################################################################################
# Script graficos de comparaci�n de centralidades
# Author: Miguel Angel Garc�a Campos - Github: angel.campos
################################################################################
library(dplyr)
library(reshape)

data <- read.delim(file = "Centralities_comparison.txt", header = T, sep = "\t")

#Network 0
# Create the data for the chart.
n1 <- as.matrix(cbind(0:2, as.numeric(data[1,5:7])/ data[1,9]))
n2 <- as.matrix(cbind(0:2, as.numeric(data[2,5:7])/ data[2,9]))
n3 <- as.matrix(cbind(0:2, as.numeric(data[3,5:7])/ data[3,9]))
n4 <- as.matrix(cbind(0:2, as.numeric(data[4,5:7])/ data[4,9]))
n5 <- as.matrix(cbind(0:2, as.numeric(data[5,5:7])/ data[5,9]))
# Give the chart file a name.
png(file = "Network0.jpg", res = 150, width = 1000, height = 1000)

#Network 0
plot(n1,type = "o",col = "red", xlab = "Grado de vecinos", 
     ylab = "N�mero de nodos cubierto", main = "Cobertura Red SG0",
     ylim = c(0,1), lwd = 2)
lines(n2, type = "o", col = "blue", lwd = 2)
lines(n3, type = "o", col = "orange", lwd = 2)
lines(n4, type = "o", col = "green", lwd = 2)
lines(n5, type = "o", col = "purple", lwd = 2)
legend("left","left", c("Degree","DBC","CI_r2", "CI_r3","CI_r4"), 
       lty=c(1,1,1), 
       lwd=c(2,2,2),col=c("red", "blue","orange","green","purple"))
dev.off()

#Network 1
# Create the data for the chart.
n1 <- as.matrix(cbind(0:2, as.numeric(data[6,5:7])/ data[6,9])) 
n2 <- as.matrix(cbind(0:2, as.numeric(data[7,5:7])/ data[7,9]))  
n3 <- as.matrix(cbind(0:2, as.numeric(data[8,5:7])/ data[8,9])) 
n4 <- as.matrix(cbind(0:2, as.numeric(data[9,5:7])/ data[9,9]))  
n5 <- as.matrix(cbind(0:2, as.numeric(data[10,5:7])/ data[10,9]))
# Give the chart file a name.
png(file = "Network1.jpg", res = 150, width = 1000, height = 1000)
# Plot the bar chart.
plot(n1,type = "o",col = "red", xlab = "Grado de vecinos", 
     ylab = "N�mero de nodos cubierto", main = "Cobertura Red SG1", 
     ylim = c(0,1), lwd = 2)
lines(n2, type = "o", col = "blue", lwd = 2)
lines(n3, type = "o", col = "orange", lwd = 2)
lines(n4, type = "o", col = "green", lwd = 2)
lines(n5, type = "o", col = "purple", lwd = 2)
legend("left","left", c("Degree","DBC","CI_r2", "CI_r3","CI_r4"), 
       lty=c(1,1,1), 
       lwd=c(2,2,2),col=c("red", "blue","orange","green","purple"))
dev.off()

#Network 2
# Create the data for the chart.
n1 <- as.matrix(cbind(0:2, as.numeric(data[11,5:7])/ data[11,9]))
n2 <- as.matrix(cbind(0:2, as.numeric(data[12,5:7])/ data[12,9]))
n3 <- as.matrix(cbind(0:2, as.numeric(data[13,5:7])/ data[13,9]))
n4 <- as.matrix(cbind(0:2, as.numeric(data[14,5:7])/ data[14,9]))
n5 <- as.matrix(cbind(0:2, as.numeric(data[15,5:7])/ data[15,9]))
# Give the chart file a name.
png(file = "Network2.jpg", res = 150, width = 1000, height = 1000)
# Plot the bar chart.
plot(n1,type = "o",col = "red", xlab = "Grado de vecinos", 
     ylab = "N�mero de nodos cubierto", main = "Cobertura Red SG2",
     ylim = c(0,1), lwd = 2)
lines(n2, type = "o", col = "blue", lwd = 2)
lines(n3, type = "o", col = "orange", lwd = 2)
lines(n4, type = "o", col = "green", lwd = 2)
lines(n5, type = "o", col = "purple", lwd = 2)
legend("left","left", c("Degree","DBC","CI_r2", "CI_r3","CI_r4"), 
       lty=c(1,1,1), 
       lwd=c(2,2,2),col=c("red", "blue","orange","green","purple"))
dev.off()

# Network 3
# Create the data for the chart.
n1 <- as.matrix(cbind(0:2, as.numeric(data[16,5:7])/ data[16,9]))
n2 <- as.matrix(cbind(0:2, as.numeric(data[17,5:7])/ data[17,9]))
n3 <- as.matrix(cbind(0:2, as.numeric(data[18,5:7])/ data[18,9]))
n4 <- as.matrix(cbind(0:2, as.numeric(data[19,5:7])/ data[19,9]))
n5 <- as.matrix(cbind(0:2, as.numeric(data[20,5:7])/ data[20,9]))
# Give the chart file a name.
png(file = "Network3.jpg", res = 150, width = 1000, height = 1000)
# Plot the bar chart.
plot(n1,type = "o",col = "red", xlab = "Grado de vecinos", 
     ylab = "N�mero de nodos cubierto", main = "Cobertura Red SG3",
     ylim = c(0,1), lwd = 2)
lines(n2, type = "o", col = "blue", lwd = 2)
lines(n3, type = "o", col = "orange", lwd = 2)
lines(n4, type = "o", col = "green", lwd = 2)
lines(n5, type = "o", col = "purple", lwd = 2)
legend("left","left", c("Degree","DBC","CI_r2", "CI_r3","CI_r4"), 
       lty=c(1,1,1), 
       lwd=c(2,2,2),col=c("red", "blue","orange","green","purple"))
dev.off()

# Network 4
# Create the data for the chart.
n1 <- as.matrix(cbind(0:2, as.numeric(data[21,5:7])/ data[21,9]))
n2 <- as.matrix(cbind(0:2, as.numeric(data[22,5:7])/ data[22,9]))
n3 <- as.matrix(cbind(0:2, as.numeric(data[23,5:7])/ data[23,9]))
n4 <- as.matrix(cbind(0:2, as.numeric(data[24,5:7])/ data[24,9]))
n5 <- as.matrix(cbind(0:2, as.numeric(data[25,5:7])/ data[25,9]))
# Give the chart file a name.
png(file = "Network4.jpg", res = 150, width = 1000, height = 1000)
# Plot the bar chart.
plot(n1,type = "o",col = "red", xlab = "Grado de vecinos", 
     ylab = "N�mero de nodos cubierto", main = "Cobertura Red SG4", 
     ylim = c(0,1), lwd = 2)
lines(n2, type = "o", col = "blue", lwd = 2)
lines(n3, type = "o", col = "orange", lwd = 2)
lines(n4, type = "o", col = "green", lwd = 2)
lines(n5, type = "o", col = "purple", lwd = 2)
legend("left","left", c("Degree","DBC","CI_r2", "CI_r3","CI_r4"), 
       lty=c(1,1,1), 
       lwd=c(2,2,2),col=c("red", "blue","orange","green","purple"))
dev.off()