################################################################################
## Integracion de resultados CI y logFC
# Tablas para graficar CI y logFC en Cytoscape
# Author: Miguel Angel Garc�a Campos - Github: angel.campos
################################################################################

# Load/Install needed packages
if (!require("reshape2")) {
  install.packages("reshape2", dependencies = TRUE)
  library(reshape2)
}
if (!require("dplyr")) {
  install.packages("dplyr", dependencies = TRUE)
  library(dplyr)
}
if (!require("VennDiagram")) {
  install.packages("VennDiagram", dependencies = TRUE)
  library(VennDiagram)
}

# Loading CI data
CI_0 <- read.delim(file = "CI_FinalNetwork_0_radio2.dat", header = F)
rownames(CI_0) <- CI_0[,1]; colnames(CI_0) <- c("Genes","CollectiveInfluence")
CI_1 <- read.delim(file = "CI_FinalNetwork_1_radio2.dat", header = F)
rownames(CI_1) <- CI_1[,1]; colnames(CI_1) <- c("Genes","CollectiveInfluence")
CI_2 <- read.delim(file = "CI_FinalNetwork_2_radio2.dat", header = F)
rownames(CI_2) <- CI_2[,1]; colnames(CI_2) <- c("Genes","CollectiveInfluence")
CI_3 <- read.delim(file = "CI_FinalNetwork_3_radio2.dat", header = F)
rownames(CI_3) <- CI_3[,1]; colnames(CI_3) <- c("Genes","CollectiveInfluence")
CI_4 <- read.delim(file = "CI_FinalNetwork_4_radio2.dat", header = F)
rownames(CI_4) <- CI_4[,1]; colnames(CI_4) <- c("Genes","CollectiveInfluence")

# Loading logFC & B-statistic data
tt1 <- read.delim(file = "Dif_exp.Healthy-SG1.txt")
rownames(tt1) <- tt1$X
tt2 <- read.delim(file = "Dif_exp.Healthy-SG2.txt")
rownames(tt2) <- tt2$X
tt3 <- read.delim(file = "Dif_exp.Healthy-SG3.txt")
rownames(tt3) <- tt3$X
tt4 <- read.delim(file = "Dif_exp.Healthy-SG4.txt")
rownames(tt4) <- tt4$X

# Load Biological process gene lists
aut <- read.delim(file = "genes_autop.txt", header = F)
aut <- as.character(as.matrix(aut))
apop <- read.delim(file = "genes_apop.txt", header = F)
apop <- as.character(as.matrix(apop))
int <- read.delim(file = "genes_inter.txt", header = F)
int <- as.character(as.matrix(int))

# Selecciona X% genes que MAS SE CONECTAN
X <- 5 # Porcentaje de genes a tomar
topg0 <- CI_0[CI_0[,2] > quantile(CI_0[,2], 1-X*0.01),]
topg1 <- CI_1[CI_1[,2] > quantile(CI_1[,2], 1-X*0.01),]
topg2 <- CI_2[CI_2[,2] > quantile(CI_2[,2], 1-X*0.01),]
topg3 <- CI_3[CI_3[,2] > quantile(CI_3[,2], 1-X*0.01),]
topg4 <- CI_4[CI_4[,2] > quantile(CI_4[,2], 1-X*0.01),]

# Extraer datos de logFC y B-stat de genes top
data1 <- tt1[tt1$X %in% rownames(topg1),c(1,2,3,7)]
data2 <- tt2[tt2$X %in% rownames(topg2),c(1,2,3,7)]
data3 <- tt3[tt3$X %in% rownames(topg3),c(1,2,3,7)]
data4 <- tt4[tt4$X %in% rownames(topg4),c(1,2,3,7)]

# Filtrar por logFC > 0.5 y B-stat > 5
lfc <- 0; b <- 5
table0 <- cbind(topg0[sort(rownames(topg0)),])
lFC1 <- data1
rownames(lFC1) <- lFC1$X
CI1 <- CI_1[CI_1$Genes %in% lFC1$X ,c(1,2)]
table1 <- cbind(lFC1[sort(rownames(lFC1)),], CI = CI1[sort(rownames(CI1)),2])
table1[table1[,"B"] <= b, c("B", "logFC")] <- 0
lFC2 <- data2
rownames(lFC2) <- lFC2$X
CI2 <- CI_2[CI_2$Genes %in% lFC2$X ,c(1,2)]
table2 <- cbind(lFC2[sort(rownames(lFC2)),], CI = CI2[sort(rownames(CI2)),2])
table2[table2[,"B"] <= b, c("B", "logFC")] <- 0
lFC3 <- data3
rownames(lFC3) <- lFC3$X
CI3 <- CI_3[CI_3$Genes %in% lFC3$X ,c(1,2)]
table3 <- cbind(lFC3[sort(rownames(lFC3)),], CI = CI3[sort(rownames(CI3)),2])
table3[table3[,"B"] <= b, c("B", "logFC")] <- 0
lFC4 <- data4
rownames(lFC4) <- lFC4$X
CI4 <- CI_4[CI_4$Genes %in% lFC4$X ,c(1,2)]
table4 <- cbind(lFC4[sort(rownames(lFC4)),], CI = CI4[sort(rownames(CI4)),2])
table4[table4[,"B"] <= b, c("B", "logFC")] <- 0

#Bioprocess labeling
tables <- c("table0", "table1","table2", "table3","table4")
for (i in tables){
  lgenes <- rownames(eval(parse(text = paste(i))))
  BPmatrix <- matrix(0, nrow = length(lgenes), ncol = 1)
  rownames(BPmatrix) <- lgenes
  colnames(BPmatrix) <- "BioProcess"
  BPmatrix[intersect(lgenes, apop),] <- c("Apoptosis")
  BPmatrix[intersect(lgenes, aut),] <- c("Autophagy")
  BPmatrix[intersect(lgenes, int),] <- c("Both")
  assign(paste(i), cbind(eval(parse(text = paste(i))), BPmatrix))
}

## Diagrama de Venn genes en subgrupos
A <- rownames(table1)
B <- rownames(table2)
C <- rownames(table3)
D <- rownames(table4)
venn.diagram(x = list(SG1=A,SG2=B,SG3=C,SG4=D), filename = "Shared_Genes.tiff",
             col = "transparent", 
             fill = c("cornflowerblue","green","yellow","darkorchid1"),
             alpha = 0.50, label.col = c("orange","white","darkorchid4","white",
                                         "white","white","white","white",
                                         "darkblue","white","white","white",
                                         "white","darkgreen","white"),
             cex = 1.5, fontfamily = "serif", fontface = "bold",
             cat.col = c("darkblue", "darkgreen", "orange", "darkorchid4"),
             cat.cex = 1.5, cat.pos = 0, cat.dist = 0.07, 
             cat.fontfamily = "serif", rotation.degree = 270, margin = 0.2)
# Healthy subgroup included
E <- rownames(topg0)
venn.diagram(x = list(SG0=E,SG1=A,SG2=B,SG3=C,SG4=D), filename = "Top_Genes.tiff",
             col = "transparent", 
             fill = c("cornflowerblue","green","yellow","darkorchid1","firebrick1" ),
             alpha = 0.50, label.col = "white",
             cex = 1.5, fontfamily = "serif", fontface = "bold",
             cat.col = c("darkblue", "darkgreen", "orange", "darkorchid4","firebrick4"),
             cat.cex = 1.5, cat.pos = 0, cat.dist = 0.07, 
             cat.fontfamily = "serif", rotation.degree = 270, margin = 0.2)

# Write tables for Cytoscape
colnames(table1)[1] <- "GeneSymbol"; colnames(table2)[1] <- "GeneSymbol"
colnames(table3)[1] <- "GeneSymbol"; colnames(table4)[1] <- "GeneSymbol"
colnames(table0) <- c("GeneSymbol", "CI", "BioProcess")
write.table(x = table0, file = "Tabla_SG0_CI_r2.txt", quote = F, sep = "\t",
            row.names = F)
write.table(x = table1, file = "Tabla_SG1_CI_r2.txt", quote = F, sep = "\t",
            row.names = F)
write.table(x = table2, file = "Tabla_SG2_CI_r2.txt", quote = F, sep = "\t",
            row.names = F)
write.table(x = table3, file = "Tabla_SG3_CI_r2.txt", quote = F, sep = "\t",
            row.names = F)
write.table(x = table4, file = "Tabla_SG4_CI_r2.txt", quote = F, sep = "\t",
            row.names = F)

save.image()
