## Script for generating MI table for Cytoscape

Net_0 <- read.delim(file = "Network_0.sif", header = F)
par <- paste("(", Net_0[,2], ")", sep = "")
test <- paste(Net_0[,1], par, Net_0[,3])
final <- cbind(test, Net_0[,2])
write.table(final, file = "MI_0.txt", quote = F, row.names = F, col.names = F, sep = "\t")

Net_1 <- read.delim(file = "Network_1.sif", header = F)
par <- paste("(", Net_1[,2], ")", sep = "")
test <- paste(Net_1[,1], par, Net_1[,3])
final <- cbind(test, Net_1[,2])
write.table(final, file = "MI_1.txt", quote = F, row.names = F, col.names = F, sep = "\t")

Net_2 <- read.delim(file = "Network_2.sif", header = F)
par <- paste("(", Net_2[,2], ")", sep = "")
test <- paste(Net_2[,1], par, Net_2[,3])
final <- cbind(test, Net_2[,2])
write.table(final, file = "MI_2.txt", quote = F, row.names = F, col.names = F, sep = "\t")

Net_3 <- read.delim(file = "Network_3.sif", header = F)
par <- paste("(", Net_3[,2], ")", sep = "")
test <- paste(Net_3[,1], par, Net_3[,3])
final <- cbind(test, Net_3[,2])
write.table(final, file = "MI_3.txt", quote = F, row.names = F, col.names = F, sep = "\t")

Net_4 <- read.delim(file = "Network_4.sif", header = F)
par <- paste("(", Net_4[,2], ")", sep = "")
test <- paste(Net_4[,1], par, Net_4[,3])
final <- cbind(test, Net_4[,2])
write.table(final, file = "MI_4.txt", quote = F, row.names = F, col.names = F, sep = "\t")