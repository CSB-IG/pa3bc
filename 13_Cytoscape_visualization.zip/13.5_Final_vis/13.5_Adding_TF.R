## Script for adding Transcription factor info to network tables

ls <- list.files()
ls <- ls[grep("Tabla", ls)]
for (i in ls) {
  x <- read.delim(file = i)
  name <- substr(i, 1,9)
  assign(name, x)
}
TF <- read.delim(file = "FactoresDeTranscripcion2016.txt", header = F)
TF <- as.character(TF[,1])

genes0 <- as.character(Tabla_SG0[,1])
TF0 <- intersect(genes0, TF)
Tabla_SG0$TransFac <- ""
Tabla_SG0[Tabla_SG0[,1] %in% TF0, "TransFac"] <- "TF"

genes1 <- as.character(Tabla_SG1[,1])
TF1 <- intersect(genes1, TF)
Tabla_SG1$TransFac <- ""
Tabla_SG1[Tabla_SG1[,1] %in% TF1, "TransFac"] <- "TF"

genes2 <- as.character(Tabla_SG2[,1])
TF2 <- intersect(genes2, TF)
Tabla_SG2$TransFac <- ""
Tabla_SG2[Tabla_SG2[,1] %in% TF2, "TransFac"] <- "TF"

genes3 <- as.character(Tabla_SG3[,1])
TF3 <- intersect(genes3, TF)
Tabla_SG3$TransFac <- ""
Tabla_SG3[Tabla_SG3[,1] %in% TF3, "TransFac"] <- "TF"

genes4 <- as.character(Tabla_SG4[,1])
TF4 <- intersect(genes4, TF)
Tabla_SG4$TransFac <- ""
Tabla_SG4[Tabla_SG4[,1] %in% TF4, "TransFac"] <- "TF"

write.table(Tabla_SG0, file = "Tabla_SG0.txt", sep = "\t", quote = F, row.names = F)
write.table(Tabla_SG1, file = "Tabla_SG1.txt", sep = "\t", quote = F, row.names = F)
write.table(Tabla_SG2, file = "Tabla_SG2.txt", sep = "\t", quote = F, row.names = F)
write.table(Tabla_SG3, file = "Tabla_SG3.txt", sep = "\t", quote = F, row.names = F)
write.table(Tabla_SG4, file = "Tabla_SG4.txt", sep = "\t", quote = F, row.names = F)

