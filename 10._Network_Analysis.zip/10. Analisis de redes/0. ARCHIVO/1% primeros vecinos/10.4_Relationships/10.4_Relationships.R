################################################################################
# Buscar el tipo de genes a los que se vinculan los nodos relevantes tras el 
# analisis de Degree-Betweenness, asi como los vinculos de los genes de cada
# proceso biologico
## Author: Miguel Angel Garcia Campos github: https://github.com/AngelCampos
################################################################################

# Install or load packages
if (!require("dplyr")) {
  install.packages("dplyr", dependencies = TRUE)
  library(dplyr)
}

## Loading SIF data
ls <- list.files()
sif <- ls[grep("Final_network", ls)]
for (i in sif) {
  name <- paste(substr(i,7,15))
  assign(name, read.delim(i, header = F))
}

## Load lists of biological processes

apo <- as.character(as.matrix(read.delim(file = "genes_apop.txt", header = F)))
aut <- as.character(as.matrix(read.delim(file = "genes_autop.txt", header = F)))
int <- as.character(as.matrix(read.delim(file = "genes_inter.txt", header = F)))

## Extraer los vecinos de cada gen en cada red
genes <- c(apo, aut, int)
for (j in 0:4){
  neigh <- list()
for (i in genes){
  x <- i == eval(parse(text = paste("network_", j, "$V1", sep="")))
  y <- i == eval(parse(text = paste("network_", j, "$V3", sep="")))
  n <- as.character(eval(parse(text = paste("network_", j, sep="")))[x,3])
  n <- c(n, as.character(eval(parse(text = paste("network_", j, sep="")))[y,1]))
  neigh[[i]] <- n
}
  name <- paste("Friends_", j, sep="")
  assign(name, neigh)
  rm(neigh, x, y, n, name) # Remove dummy variables
  print(paste("Network",j, "done!"))
}

# Grado de conexion de cada gen con genes de Apoptosis/Autofagia/

allgenes <- unique(c(as.matrix(network_1$V1), as.matrix(network_1$V3)))
# Non apoptotic nor authopagic genes
nogenes <- Reduce(setdiff, list(allgenes,apo,aut,int))
Relationship <- list()
for (i in genes){
  a <- sum(Friends_1[[i]] %in% apo) / length(Friends_1[[i]])
  b <- sum(Friends_1[[i]] %in% aut) / length(Friends_1[[i]])
  c <- sum(Friends_1[[i]] %in% int) / length(Friends_1[[i]])
  d <- sum(Friends_1[[i]] %in% nogenes) / length(Friends_1[[i]])
  r <- c(a,b,c,d)
  names(r) <- c("Apoptosis","Autophagy","Both","None")
  Relationship[[i]] <- r
}

a <- sum(Friends_1$MOAP1 %in% apo) / length(Friends_1$MOAP1)
b <- sum(Friends_1$MOAP1 %in% aut) / length(Friends_1$MOAP1)
c <- sum(Friends_1$MOAP1 %in% int) / length(Friends_1$MOAP1)
d <- sum(Friends_1$MOAP1 %in% nogenes) / length(Friends_1$MOAP1)
sum(a,b,c,d)
r <- c(a,b,c,d) #Relationships Degree
