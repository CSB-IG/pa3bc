# Who is who Apoptosis/autophagy or Intersection genes

# Load gene list to compare
lgenes <- read.delim(file = "Final_genes.txt", header = F)
lgenes <- as.character(as.matrix(lgenes))

# Load Biological process gene lists
aut <- read.delim(file = "genes_autop.txt", header = F)
aut <- as.character(as.matrix(aut))
apop <- read.delim(file = "genes_apop.txt", header = F)
apop <- as.character(as.matrix(apop))
int <- read.delim(file = "genes_inter.txt", header = F)
int <- as.character(as.matrix(int))

# Numero de genes detectados pertenecientes a procesos celulares
length(intersect(lgenes, apop)) # Apoptotic process genes
length(intersect(lgenes, aut)) # Autophagic process genes
length(intersect(lgenes, int)) # Both processes genes

# Proportion of genes/process
length(intersect(lgenes, apop))/length(apop) # Apoptotic process genes
length(intersect(lgenes, aut))/length(aut) # Autophagic process genes
length(intersect(lgenes, int))/length(int) # Both processes genes

# Matrix of Biological process
BPmatrix <- matrix(0, nrow = length(lgenes), ncol = 1)
rownames(BPmatrix) <- lgenes
colnames(BPmatrix) <- "BioProcess"
BPmatrix[intersect(lgenes, apop),] <- c("Apop")
BPmatrix[intersect(lgenes, aut),] <- c("Auto")
BPmatrix[intersect(lgenes, int),] <- c("Inter")

write.table(BPmatrix, "Final_genes_BioProcess.txt", quote = F, col.names = NA,
            sep = "\t")
