################################################################################
# Calculating Degree+Betweeness-Centrality hybrid measure
# Implementation from Abbasi & Hossain, 2006 - Hybrid Centrality Measures for 
# Binary and Weighted Networks
## Author: Miguel Angel Garc�a Campos
################################################################################

# Install or load packages
if (!require("dplyr")) {
  install.packages("dplyr", dependencies = TRUE)
  library(dplyr)
}

## Reading results
ls <- list.files()
res <- ls[grep(".nattributes", ls)]

## Loading network attributes
for (i in res) {
  name <- paste(substr(i,1,11))
  assign(name, read.delim(i))
}

## Loading SIF data
sif <- ls[grep("Final_network", ls)]
for (i in sif) {
  name <- paste(substr(i,7,15))
  assign(name, read.delim(i, header = F))
}

## Loading subnetworks data
csv <- ls[grep(".csv", ls)]
for (i in csv) {
  name <- paste(substr(i,1,10))
  assign(name, read.csv(i))
}

# Remove nodes not pertaining to main component
x <- Network_SG0$Node %in% Subnet_SG0$name
Network_SG0 <- Network_SG0[!x,]
x <- Network_SG1$Node %in% Subnet_SG1$name
Network_SG1 <- Network_SG1[!x,]
x <- Network_SG2$Node %in% Subnet_SG2$name
Network_SG2 <- Network_SG2[!x,]
x <- Network_SG3$Node %in% Subnet_SG3$name
Network_SG3 <- Network_SG3[!x,]
x <- Network_SG4$Node %in% Subnet_SG4$name
Network_SG4 <- Network_SG4[!x,]

# Extract node-degree-Betweeness information for ALL results
nicks <- substr(res,1,11) # Variable for names and loop usage
for (i in nicks){
  name <- paste(i)
  assign(name, select(eval(parse(text = i)), Node = Node.ID,
                      Degree, BetweennessCentrality))
}

# Removing dummy variables
rm(Subnet_SG0,Subnet_SG1, Subnet_SG2, Subnet_SG3, Subnet_SG4, csv,x)

# Add rownames for genes
rownames(Network_SG0) <- Network_SG0[,1]
rownames(Network_SG1) <- Network_SG1[,1]
rownames(Network_SG2) <- Network_SG2[,1]
rownames(Network_SG3) <- Network_SG3[,1]
rownames(Network_SG4) <- Network_SG4[,1]

# Calculate Degree-BetweennessCentrality (DBC) for all networks (0-4)
for (j in 0:4){
  genes <- as.matrix(eval(parse(text = paste("Network_SG", j, "$Node",sep=""))))
  genes <- unique(as.character(genes)) # Network's genes
  neigh <- list()
  for (i in genes){
    x <- i == eval(parse(text = paste("network_", j, "$V1", sep="")))
    y <- i == eval(parse(text = paste("network_", j, "$V3", sep="")))
    n <- as.character(eval(parse(text = paste("network_", j, sep="")))[x,3])
    n <- c(n, as.character(eval(parse(text = paste("network_", j, sep="")))[y,1]))
    neigh[[i]] <- n
  }
  DBC <- NULL
  for(i in genes){
      s <- sum(eval(parse(text = paste("Network_SG",j, sep="")))[neigh[[i]],3])
      DBC <- c(DBC, s)
  }
  name <- paste("DBC_", j, sep="")
  names(DBC) <- genes
  DBC <- as.matrix(DBC)
  assign(name, DBC)
  print(paste("Network",j, "done!"))
}

# Change column names of DBC's tables
colnames(DBC_0) <- "Degree_BC"; colnames(DBC_1) <- "Degree_BC"; 
colnames(DBC_2) <- "Degree_BC"; colnames(DBC_3) <- "Degree_BC"
colnames(DBC_4) <- "Degree_BC"

# Guardar resultados
for (i in c("DBC_0","DBC_1","DBC_2","DBC_3","DBC_4")){
  test <- data.frame(Genes = rownames(eval(parse(text = paste(i)))),
                     Degree_BC = eval(parse(text = paste(i)))[,1])
  test <- arrange(test, desc(Degree_BC))
  filename <- paste(i,".txt", sep ="")
  write.table(test, filename, sep = "\t", col.names = T, quote = F, row.names = F)
}