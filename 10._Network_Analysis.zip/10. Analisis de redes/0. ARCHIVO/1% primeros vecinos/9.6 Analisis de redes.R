# Results of network analysis

# Loading packages
library(dplyr); library(magrittr); library(reshape2); library(gplots)

## Reading results
ls <- list.files()
res <- ls[grep(".nattributes", ls)]
for (i in res) {
  name <- paste(substr(i,1,11))
  assign(name, read.delim(i))
}

csv <- ls[grep(".csv", ls)]
for (i in csv) {
  name <- paste(substr(i,1,10))
  assign(name, read.csv(i))
}
rm(ls)

# Extract node-degree-Betweeness information for ALL results
nicks <- substr(res,1,11)
for (i in nicks){
  name <- paste(i)
  assign(name, select(eval(parse(text = i)), Node = Node.ID,
                      Degree, BetweennessCentrality))
}

# Remove nodes not pertaining to main component
x <- Network_SG0$Node %in% Subnet_SG0$name
Network_SG0 <- Network_SG0[!x,]
x <- Network_SG1$Node %in% Subnet_SG1$name
Network_SG1 <- Network_SG1[!x,]
x <- Network_SG2$Node %in% Subnet_SG2$name
Network_SG2 <- Network_SG2[!x,]
x <- Network_SG3$Node %in% Subnet_SG3$name
Network_SG3 <- Network_SG3[!x,]
x <- Network_SG4$Node %in% Subnet_SG4$name
Network_SG4 <- Network_SG4[!x,]

rm(Subnet_SG0,Subnet_SG1, Subnet_SG2, Subnet_SG3, Subnet_SG4, csv,x)

# Add Subgroup name to node
for (i in nicks){
  name <- paste(i)
  assign(name, mutate(eval(parse(text = i)), SubGroup = name))
}

# Add rownames for genes
rownames(Network_SG0) <- Network_SG0[,1]
rownames(Network_SG1) <- Network_SG1[,1]
rownames(Network_SG2) <- Network_SG2[,1]
rownames(Network_SG3) <- Network_SG3[,1]
rownames(Network_SG4) <- Network_SG4[,1]

# Score nodes for High Betweenness and Degree
for (i in nicks){
  name <- paste(i)
  nDegree <- eval(parse(text = i))[,2]/(length(eval(parse(text = i))[,2])-1) # Degree Centrality
  Score <- nDegree * eval(parse(text = i))[,3] # Multiply DegreeCentrality and Betweeness Centrality
  nScore <- (Score-min(Score))/(max(Score)-min(Score))
  nScore <- signif(nScore, 6)
  df <- mutate(eval(parse(text = i)), DegreeCentrality = nDegree, 
               SubGroup = SubGroup, Score = nScore)
  assign(name, df[,c(1,4,2,3,5,6)])
}
rm(Score,nScore,nDegree)

# Sorting descending order by Score, Degree and Betweenness
for (i in nicks){
  name <- paste(i)
  assign(name, arrange(eval(parse(text = i)), desc(Score), desc(DegreeCentrality), 
                       desc(BetweennessCentrality), desc(Degree)))
}

# Aggregate all results as long format
all_res <- Reduce(rbind,list(Network_SG0,Network_SG1,Network_SG2,Network_SG3,
                             Network_SG4))

# Extraer datos en formato ancho
# Resultados por GRADO
res_Degree <- dcast(all_res, formula = Node ~ SubGroup, value.var = "DegreeCentrality")
res_Degree[is.na(res_Degree)] <- 0
# Resultados por Betweenness
res_BC <- dcast(all_res, formula = Node ~ SubGroup, value.var = "BetweennessCentrality")
res_BC[is.na(res_BC)] <- 0
# Resultados por Score
res_Score <- dcast(all_res, formula = Node ~ SubGroup, value.var = "Score")
res_Score[is.na(res_Score)] <- 0


# Seleccionar los genes con cambios entre el fenotipo saludable y enfermo
# DEGREE
dif <- NULL
for (i in 1:length(res_Degree[,1])){
  d <- max(abs(res_Degree[i,3:6] - res_Degree[i,2])) # Select Max dif
  dif <- c(dif,d)
}
dif <- dif > quantile(dif,.975)
dif_Degree <- res_Degree[dif,]

# Por BC
dif <- NULL
for (i in 1:length(res_BC[,1])){
  d <- max(abs(res_BC[i,3:6] - res_BC[i,2])) # Select Max dif
  dif <- c(dif,d)
}
dif <- dif > quantile(dif,.975) # 5% Mas diferente en alg�n fenotipo
dif_BC <- res_BC[dif,]

# Por Score
#2.5%
dif <- NULL
for (i in 1:length(res_Score[,1])){
  d <- max(abs(res_Score[i,2] - res_Score[i,3:6])) # Selec Max dif
  dif <- c(dif,d)
}
dif <- dif > quantile(dif,.975)
dif_Score <- res_Score[dif,]

# 1 %
dif <- NULL
for (i in 1:length(res_Score[,1])){
  d <- max(abs(res_Score[i,2] - res_Score[i,3:6])) # Selec Max dif
  dif <- c(dif,d)
}
dif <- dif > quantile(dif,.99)
dif_ScorePRIME <- res_Score[dif,]

# Genes "importantes"
VIPg_Degree <- as.character(dif_Degree[,1])
VIPg_BC <- as.character(dif_BC[,1])
VIPg_Score <- as.character(dif_Score[,1])
VIPg_Score_1 <- as.character(dif_ScorePRIME[,1])

# Write results
write(x = VIPg_Score, file = "2.5% genes.txt", sep = "\t")
write(x = VIPg_Score_1, file = "1% genes.txt", sep = "\t")
write.table(x = dif_Score, file = "2.5% genes Scores.txt", sep = "\t", 
            quote = F, row.names = FALSE)


# Load Biological process gene lists
aut <- read.delim(file = "genes_autop.txt", header = F)
aut <- as.character(as.matrix(aut))
apop <- read.delim(file = "genes_apop.txt", header = F)
apop <- as.character(as.matrix(apop))
int <- read.delim(file = "genes_inter.txt", header = F)
int <- as.character(as.matrix(int))

# Pruebas de similaridad
## Similitud resultados Score vs Degree
length(intersect(VIPg_Score, VIPg_Degree))/length(VIPg_Score)
## Similitud resultados Score vs BetweennessC
length(intersect(VIPg_Score, VIPg_BC))/length(VIPg_Score)
## Similitud resultados Degree vs BetweennessC
length(intersect(VIPg_Degree, VIPg_BC))/length(VIPg_Degree)

# Numero de genes detectados pertenecientes a procesos celulares
length(intersect(VIPg_Score, apop)) # Apoptotic process genes
length(intersect(VIPg_Score, aut)) # Autophagic process genes
length(intersect(VIPg_Score, int)) # Both processes genes

length(intersect(VIPg_Score_1, apop)) # Apoptotic process genes
length(intersect(VIPg_Score_1, aut)) # Autophagic process genes
length(intersect(VIPg_Score_1, int)) # Both processes genes


length(intersect(VIPg_Degree, apop))
length(intersect(VIPg_Degree, aut))
length(intersect(VIPg_Degree, int))

# Results plots
heatmap(as.matrix(dif_Score[,-1]), main = "Score between subgroups")
heatmap(as.matrix(dif_BC[,-1]), main = "BC between subgroups")
heatmap(as.matrix(dif_Degree[,-1]), main = "Degree between subgroups")
heatmap.2(as.matrix(dif_Degree[,-1]), main = "Degree between subgroups",
          trace = "none")

# Top Overall Genes
Top_ScoreG <- arrange(all_res, desc(Score))
Top_ScoreG <- head(as.character(unique(Top_ScoreG[,1])), 120)
length(intersect(Top_ScoreG, VIPg_Score)) # 116 genes 
setdiff(Top_ScoreG, VIPg_Score) # 4 genes que no est�n en el top 1% dif pero tienen Score alto

#Additional plots
# Plots Degree vs Betweenness
plot(Network_SG0$BetweennessCentrality, Network_SG0$Degree)
plot(Network_SG1$BetweennessCentrality, Network_SG1$Degree)
plot(Network_SG2$BetweennessCentrality, Network_SG2$Degree)
plot(Network_SG3$BetweennessCentrality, Network_SG3$Degree)
plot(Network_SG4$BetweennessCentrality, Network_SG4$Degree)

# Plot DegreCentrality vs BetweennessCentrality
plot(Network_SG0$BetweennessCentrality, Network_SG0$Degree/length(Network_SG0[,2]-1))

