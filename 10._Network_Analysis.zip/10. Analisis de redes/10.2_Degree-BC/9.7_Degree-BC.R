################################################################################
# Calculating Degree+Betweeness-Centrality hybrid measure
# Implementation from Abbasi & Hossain, 2006 - Hybrid Centrality Measures for 
# Binary and Weighted Networks
## Author: Miguel Angel Garc�a Campos
################################################################################

# Install or load packages
if (!require("dplyr")) {
  install.packages("dplyr", dependencies = TRUE)
  library(dplyr)
}

## Reading results
ls <- list.files()
res <- ls[grep(".nattributes", ls)]
sif <- ls[grep("Final", ls)]
## Loading network attributes
for (i in res) {
  name <- paste("Net_", substr(i,9,9), "_att", sep = "")
  assign(name, read.delim(i))
}
## Loading SIF data
for (i in sif) {
  name <- paste("Net_",substr(i,14,14), sep = "")
  assign(name, read.delim(i, header = F))
}
# Extract node-degree-Betweeness information for ALL results
v <- ls()
nicks <- v[grep("att", v)]  # Variable for names and loop usage
for (i in nicks){
  name <- paste(i)
  assign(name, select(eval(parse(text = i)), Node = Node.ID,
                      Degree, BetweennessCentrality))
}

# Add rownames for genes
rownames(Net_0_att) <- Net_0_att[,1]
rownames(Net_1_att) <- Net_1_att[,1]
rownames(Net_2_att) <- Net_2_att[,1]
rownames(Net_3_att) <- Net_3_att[,1]
rownames(Net_4_att) <- Net_4_att[,1]

# Calculate Degree-BetweennessCentrality (DBC) for all networks (0-4)
for (j in 0:4){
  genes <- as.matrix(eval(parse(text = paste("Net_", j,"_att","$Node",sep=""))))
  genes <- unique(as.character(genes)) # Network's genes
  neigh <- list()
  for (i in genes){
    x <- i == eval(parse(text = paste("Net_", j, "$V1", sep="")))
    y <- i == eval(parse(text = paste("Net_", j, "$V3", sep="")))
    n <- as.character(eval(parse(text = paste("Net_", j, sep="")))[x,3])
    n <- c(n, as.character(eval(parse(text = paste("Net_", j, sep="")))[y,1]))
    neigh[[i]] <- n
  }
  DBC <- NULL
  for(i in genes){
      s <- sum(eval(parse(text = paste("Net_",j, "_att", sep="")))[neigh[[i]],3])
      DBC <- c(DBC, s)
  }
  name <- paste("DBC_", j, sep="")
  names(DBC) <- genes
  DBC <- as.matrix(DBC)
  assign(name, DBC)
  print(paste("Network",j, "done!"))
}

# Change column names of DBC's tables
colnames(DBC_0) <- "Degree_BC"; colnames(DBC_1) <- "Degree_BC"; 
colnames(DBC_2) <- "Degree_BC"; colnames(DBC_3) <- "Degree_BC"
colnames(DBC_4) <- "Degree_BC"

# Guardar resultados
for (i in c("DBC_0","DBC_1","DBC_2","DBC_3","DBC_4")){
  test <- data.frame(Genes = rownames(eval(parse(text = paste(i)))),
                     Degree_BC = eval(parse(text = paste(i)))[,1])
  test <- arrange(test, desc(Degree_BC))
  filename <- paste(i,".txt", sep ="")
  write.table(test, filename, sep = "\t", col.names = T, quote = F, row.names = F)
}