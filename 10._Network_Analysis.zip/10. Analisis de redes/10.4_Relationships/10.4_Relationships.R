################################################################################
# Genera un archivo en el que se muestra la proporci�n de vecinos que pertenecen
# a una de tre categorias de genes (Apoptosis, Autofagia o ambos)
## Author: Miguel Angel Garcia Campos github: https://github.com/AngelCampos
################################################################################

# Install or load packages
if (!require("dplyr")) {
  install.packages("dplyr", dependencies = TRUE)
  library(dplyr)
}
if (!require("RColorBrewer")) {
  install.packages("RColorBrewer", dependencies = TRUE)
  library(RColorBrewer)
}

## Loading SIF data
ls <- list.files()
sif <- ls[grep("FinalNetwork", ls)]
for (i in sif) {
  name <- paste(substr(i,6,14))
  assign(name, read.delim(i, header = F))
}

## Load lists of biological processes
apo <- as.character(as.matrix(read.delim(file = "genes_apop.txt", header = F)))
aut <- as.character(as.matrix(read.delim(file = "genes_autop.txt", header = F)))
int <- as.character(as.matrix(read.delim(file = "genes_inter.txt", header = F)))

## Extraer los vecinos de cada gen en cada red
for (j in 0:4){
  genes <- c(as.matrix(eval(parse(text = paste("Network_", j, "$V1", sep="")))),
             as.matrix(eval(parse(text = paste("Network_", j, "$V3", sep="")))))
  genes <- unique(genes)
  neigh <- list()
  for (i in genes){
    x <- i == eval(parse(text = paste("Network_", j, "$V1", sep="")))
    y <- i == eval(parse(text = paste("Network_", j, "$V3", sep="")))
    n <- as.character(eval(parse(text = paste("Network_", j, sep="")))[x,3])
    n <- c(n,as.character(eval(parse(text =paste("Network_", j, sep="")))[y,1]))
    neigh[[i]] <- n
  }
  name <- paste("Friends_", j, sep="")
  assign(name, neigh)
  rm(neigh, x, y, n, name) # Remove dummy variables
  print(paste("Network",j, "done!"))
}

# Grado de conexion de cada gen con genes de Apoptosis/Autofagia/Ambos
for (j in 0:4){
  genes<-unique(c(as.matrix(eval(parse(text=paste("Network_",j,"$V1",sep="")))),
                  as.matrix(eval(parse(text=paste("Network_",j,"$V3",sep=""))))))
  Relationship <- NULL
  for (i in genes){
    a <- sum(eval(parse(text= paste("Friends_", j, sep="")))[[i]] %in% apo)
    b <- sum(eval(parse(text= paste("Friends_", j, sep="")))[[i]] %in% aut)
    c <- sum(eval(parse(text= paste("Friends_", j, sep="")))[[i]] %in% int)
    d <- sum(a,b,c)
    r <- c(a,b,c,d)
    names(r) <- c("Apoptosis","Autophagy","Both", "Total")
    Relationship <- rbind(Relationship, r)
  }
  biop <- as.character(NULL)
  length(biop) <- length(genes);  names(biop) <- genes
  for (i in genes){
    if (i %in% apo) {biop[i] <- "Apoptosis"}
    if (i %in% aut) {biop[i] <- "Autophagy"}
    if (i %in% int) {biop[i] <- "Both"}
  }
  rownames(Relationship) <- genes
  Rel <- data.frame(Relationship, Bioprocess = biop)
  arrange(Rel, desc(Total))
  name <- paste("Relationship_", j, sep="")
  assign(name, Rel) # Name of Relationship variable
  # rm(Relationship) #Remove dummy variables
  print(paste("Relationships of Network",j, "ready!"))
}

# Write Relationship Results
v <- c("Relationship_0","Relationship_1","Relationship_2","Relationship_3",
       "Relationship_4")
for (i in v){
  write.table(x = eval(parse(text = i)), file = paste(i, ".txt", sep = ""),
              col.names = NA, quote = F, sep = "\t", row.names = T)
}

################################################################################
## Cuanto se conectan los genes de un procesos entre si y con el otro
CON <- NULL # Iniciar variable para guardar resultados
# Red 0
ap <- length(Relationship_0[Relationship_0[,"Bioprocess"] =="Apoptosis",5])
au <- length(Relationship_0[Relationship_0[,"Bioprocess"] =="Autophagy",5])
bo <- length(Relationship_0[Relationship_0[,"Bioprocess"] =="Both",5])
# V�nculos de genes de apoptosis - apoptosis
u <- sum(Relationship_0[Relationship_0[,"Bioprocess"] == "Apoptosis", 1])/2
u <- u/((ap*(ap-1))/2)
# V�nculos de genes de autofagia - autofagia
v <- sum(Relationship_0[Relationship_0[,"Bioprocess"] == "Autophagy",2 ])/2
v <- v/((au*(au-1))/2)
# V�nculos entre genes de ambos procesos
w <- sum(Relationship_0[Relationship_0[,"Bioprocess"] == "Both", 3 ])/2
w <- w/((bo*(bo-1))/2)
# V�nculos de genes de Autofagia - Apoptosis
x <- sum(Relationship_0[Relationship_0[,"Bioprocess"] == "Autophagy", 1 ])
x <- x/(au*ap)
# V�nculos Apoptosis - Both
y <- sum(Relationship_0[Relationship_0[,"Bioprocess"] == "Apoptosis", 3])
y <- y/(ap*bo)
# V�nculos Autofagia - Both
z <- sum(Relationship_0[Relationship_0[,"Bioprocess"] == "Autophagy", 3 ])
z <- z/(au*bo)
D_0 <- dim(Network_0)[1] / ((ap+au+bo)*(ap+au+bo-1)/2)
# Results
r0 <- c(u,v,w,x,y,z)
names(r0) <- c("Apo-Apo","Aut-Aut","Both-Both","Apo-Aut","Apo-Both","Aut-Both")
png(filename = "Conexiones_Red0.png", width = 600, height = 450, pointsize = 14)
barplot(r0, col = brewer.pal(6, "Set1" ), main = "Red 0", ylim = c(0, max(r0)),
        ylab = "Densidad", xlab = "Procesos en conexi�n")
dev.off()
CON <- rbind(CON, r0)

# Red 1
ap <- length(Relationship_1[Relationship_1[,"Bioprocess"] =="Apoptosis",5])
au <- length(Relationship_1[Relationship_1[,"Bioprocess"] =="Autophagy",5])
bo <- length(Relationship_1[Relationship_1[,"Bioprocess"] =="Both",5])
# V�nculos de genes de apoptosis - apoptosis
u <- sum(Relationship_1[Relationship_1[,"Bioprocess"] == "Apoptosis", 1])/2
u <- u/((ap*(ap-1))/2)
# V�nculos de genes de autofagia - autofagia
v <- sum(Relationship_1[Relationship_1[,"Bioprocess"] == "Autophagy",2])/2
v <- v/((au*(au-1))/2)
# V�nculos entre genes de ambos procesos
w <- sum(Relationship_1[Relationship_1[,"Bioprocess"] == "Both", 3])/2
w <- w/((bo*(bo-1))/2)
# V�nculos de genes de Autofagia - Apoptosis
x <- sum(Relationship_1[Relationship_1[,"Bioprocess"] == "Autophagy", 1])
x <- x/(au*ap)
# V�nculos Apoptosis - Both
y <- sum(Relationship_1[Relationship_1[,"Bioprocess"] == "Apoptosis", 3])
y <- y/(ap*bo)
# V�nculos Autofagia - Both
z <- sum(Relationship_1[Relationship_1[,"Bioprocess"] == "Autophagy", 3])
z <- z/(au*bo)
D_1 <- dim(Network_1)[1] / ((ap+au+bo)*(ap+au+bo-1)/2)
# Results
r1 <- c(u,v,w,x,y,z)
names(r1) <- c("Apo-Apo","Aut-Aut","Both-Both","Apo-Aut","Apo-Both","Aut-Both")
png(filename = "Conexiones_Red1.png", width = 600, height = 450, pointsize = 14)
barplot(r1, col = brewer.pal(6, "Set1" ), main = "Red 1", ylim = c(0, 0.035),
        ylab = "Densidad", xlab = "Procesos en conexi�n")
dev.off()
CON <- rbind(CON, r1)
# Red 2
ap <- length(Relationship_2[Relationship_2[,"Bioprocess"] =="Apoptosis",5])
au <- length(Relationship_2[Relationship_2[,"Bioprocess"] =="Autophagy",5])
bo <- length(Relationship_2[Relationship_2[,"Bioprocess"] =="Both",5])
# V�nculos de genes de apoptosis - apoptosis
u <- sum(Relationship_2[Relationship_2[,"Bioprocess"] == "Apoptosis", 1])/2
u <- u/((ap*(ap-1))/2)
# V�nculos de genes de autofagia - autofagia
v <- sum(Relationship_2[Relationship_2[,"Bioprocess"] == "Autophagy",2 ])/2
v <- v/((au*(au-1))/2)
# V�nculos entre genes de ambos procesos
w <- sum(Relationship_2[Relationship_2[,"Bioprocess"] == "Both", 3 ])/2
w <- w/((bo*(bo-1))/2)
# V�nculos de genes de Autofagia - Apoptosis
x <- sum(Relationship_2[Relationship_2[,"Bioprocess"] == "Autophagy", 1 ])
x <- x/(au*ap)
# V�nculos Apoptosis - Both
y <- sum(Relationship_2[Relationship_2[,"Bioprocess"] == "Apoptosis", 3])
y <- y/(ap*bo)
# V�nculos Autofagia - Both
z <- sum(Relationship_2[Relationship_2[,"Bioprocess"] == "Autophagy", 3 ])
z <- z/(au*bo)
D_2 <- dim(Network_2)[1] / ((ap+au+bo)*(ap+au+bo-1)/2)
# Results
r2 <- c(u,v,w,x,y,z)
names(r2) <- c("Apo-Apo","Aut-Aut","Both-Both","Apo-Aut","Apo-Both","Aut-Both")
png(filename = "Conexiones_Red2.png", width = 600, height = 450, pointsize = 14)
barplot(r2, col = brewer.pal(6, "Set1" ), main = "Red 2", ylim = c(0, 0.035),
        ylab = "Densidad", xlab = "Procesos en conexi�n")
dev.off()
CON <- rbind(CON, r2)

# Red 3
ap <- length(Relationship_3[Relationship_3[,"Bioprocess"] =="Apoptosis",5])
au <- length(Relationship_3[Relationship_3[,"Bioprocess"] =="Autophagy",5])
bo <- length(Relationship_3[Relationship_3[,"Bioprocess"] =="Both",5])
# V�nculos de genes de apoptosis - apoptosis
u <- sum(Relationship_3[Relationship_3[,"Bioprocess"] == "Apoptosis", 1])/2
u <- u/((ap*(ap-1))/2)
# V�nculos de genes de autofagia - autofagia
v <- sum(Relationship_3[Relationship_3[,"Bioprocess"] == "Autophagy",2 ])/2
v <- v/((au*(au-1))/2)
# V�nculos entre genes de ambos procesos
w <- sum(Relationship_3[Relationship_3[,"Bioprocess"] == "Both", 3 ])/2
w <- w/((bo*(bo-1))/2)
# V�nculos de genes de Autofagia - Apoptosis
x <- sum(Relationship_3[Relationship_3[,"Bioprocess"] == "Autophagy", 1 ])
x <- x/(au*ap)
# V�nculos Apoptosis - Both
y <- sum(Relationship_3[Relationship_3[,"Bioprocess"] == "Apoptosis", 3])
y <- y/(ap*bo)
# V�nculos Autofagia - Both
z <- sum(Relationship_3[Relationship_3[,"Bioprocess"] == "Autophagy", 3 ])
z <- z/(au*bo)
D_3 <- dim(Network_3)[1] / ((ap+au+bo)*(ap+au+bo-1)/2)
# Results
r3 <- c(u,v,w,x,y,z)
names(r3) <- c("Apo-Apo","Aut-Aut","Both-Both","Apo-Aut","Apo-Both","Aut-Both")
png(filename = "Conexiones_Red3.png", width = 600, height = 450, pointsize = 14)
barplot(r3, col = brewer.pal(6, "Set1" ), main = "Red 3", ylim = c(0, 0.035),
        ylab = "Densidad", xlab = "Procesos en conexi�n")
dev.off()
CON <- rbind(CON, r3)

# Red 4
ap <- length(Relationship_4[Relationship_4[,"Bioprocess"] =="Apoptosis",5])
au <- length(Relationship_4[Relationship_4[,"Bioprocess"] =="Autophagy",5])
bo <- length(Relationship_4[Relationship_4[,"Bioprocess"] =="Both",5])
# V�nculos de genes de apoptosis - apoptosis
u <- sum(Relationship_4[Relationship_4[,"Bioprocess"] == "Apoptosis", 1])/2
u <- u/((ap*(ap-1))/2)
# V�nculos de genes de autofagia - autofagia
v <- sum(Relationship_4[Relationship_4[,"Bioprocess"] == "Autophagy",2 ])/2
v <- v/((au*(au-1))/2)
# V�nculos entre genes de ambos procesos
w <- sum(Relationship_4[Relationship_4[,"Bioprocess"] == "Both", 3 ])/2
w <- w/((bo*(bo-1))/2)
# V�nculos de genes de Autofagia - Apoptosis
x <- sum(Relationship_4[Relationship_4[,"Bioprocess"] == "Autophagy", 1 ])
x <- x/(au*ap)
# V�nculos Apoptosis - Both
y <- sum(Relationship_4[Relationship_4[,"Bioprocess"] == "Apoptosis", 3])
y <- y/(ap*bo)
# V�nculos Autofagia - Both
z <- sum(Relationship_4[Relationship_4[,"Bioprocess"] == "Autophagy", 3 ])
z <- z/(au*bo)
D_4 <- dim(Network_4)[1] / ((ap+au+bo)*(ap+au+bo-1)/2)
# Results
r4 <- c(u,v,w,x,y,z)
names(r4) <- c("Apo-Apo","Aut-Aut","Both-Both","Apo-Aut","Apo-Both","Aut-Both")
png(filename = "Conexiones_Red4.png", width = 600, height = 450, pointsize = 14)
barplot(r4, col = brewer.pal(6, "Set1" ), main = "Red 4",
        ylim = c(0, 0.035), ylab = "Densidad", xlab = "Procesos en conexi�n")
dev.off()
CON <- rbind(CON, r4)

# Densidad de las redes tomando en cuenta todos los nodos
D <- c(D_0, D_1, D_2, D_3, D_4)
names(D) <- c("SG0","SG1","SG2","SG3","SG4")
png(filename = "Densidad_redes.png", width = 600, height = 450, pointsize = 14)
barplot(D, col = brewer.pal(6, "Set1" ), main = "Densidad total",
        ylim = c(0, 0.08), ylab = "Densidad", xlab = "Red")
dev.off()

## Final Results
CON <- as.matrix(CON)
rownames(CON) <- matrix(c("SG0","SG1","SG2","SG3","SG4"))
png(filename = "Conexiones_Todos.png", width = 600, height = 450, pointsize =14)
barplot(t(CON), col = brewer.pal(6, "Set1" ), beside = T, 
        main = "Todos los subgrupos", ylab = "Densidad", xlab = "Subgrupos")
dev.off()

# Write to file
write.table(CON, "BioProcess_Connection.txt", quote = F, sep = "\t", 
            col.names = NA)
